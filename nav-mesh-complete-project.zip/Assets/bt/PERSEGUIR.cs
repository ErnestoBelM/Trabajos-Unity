using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TheKiwiCoder;

public class PERSEGUIR : ActionNode
{
    protected override void OnStart() {
        Debug.Log("start");
    }

    protected override void OnStop() {
        
    }

    protected override State OnUpdate() {
        Debug.Log("update");
        return State.Success;
        
    }
}
