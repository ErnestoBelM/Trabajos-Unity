using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    [SerializeField]
    GameObject circle;

    // Start is called before the first frame update
    void Start()
    {




    }
    

    // Update is called once per frame
    void Update()
    {
        bool spacePressed = Input.GetKeyDown("space");
       if (spacePressed){

            SpawnObject();
       }





        
        //Instantiate(circle, Vector3.zero, Quaternion.identity); //Vector3.zero es igual a new Vector3(0, 0, 0);
        

    }

    void SpawnObject()
    {

        int lado = Random.Range(1, 4);
       bool spacePressed = Input.GetKeyDown("space");
       Vector2 posicion = new Vector2( Random.Range(0, Screen.width), Random.Range(0, Screen.height));

    


       if (spacePressed)
       {

        if (lado == 1) {
            posicion.x = 0;
        }

        if (lado == 2) {
            posicion.y = Screen.height;

        }
        if (lado == 3) {
            posicion.x = Screen.width;

        }
        if (lado == 4) {
            posicion.y = 0;
        }

           Vector2 posicionjuego = Camera.main.ScreenToWorldPoint(posicion);

        Instantiate(circle, (Vector3) posicionjuego  , Quaternion.identity);
       }


    }
    
}
