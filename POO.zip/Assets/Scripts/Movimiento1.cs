using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movimiento1 : MonoBehaviour
{
    float velocidad = 0.01f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float vertical = Input.GetAxis("Vertical2");
        Vector3 direction = new Vector3(0, vertical, 0);
        transform.position += direction * velocidad;
    }
}
