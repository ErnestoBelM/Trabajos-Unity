using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movimiento : MonoBehaviour
{
    float velocidad = 0.01f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float vertical = Input.GetAxis("Vertical");
        Vector3 direction = new Vector3(0, vertical, 0);
        transform.position += direction * velocidad;

        bool spacePressed = Input.GetKey(KeyCode.Space);
        Debug.Log("HOLA");


        if (Input.GetKey(KeyCode.A) && Input.GetKey(KeyCode.B)) {
            Debug.Log("AB");

        } else if (Input.GetKey(KeyCode.A)){
            Debug.Log("A");

           
        }
        else if (Input.GetKey(KeyCode.B)){
            Debug.Log("B");

        }








    }
}
