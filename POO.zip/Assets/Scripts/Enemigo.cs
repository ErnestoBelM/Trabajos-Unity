using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemigo : MonoBehaviour
{

    float velocidad = 0.001f;
    Vector3 direccion = Vector3.zero;

    // Start is called before the first frame update
    void Start()
    {
            direccion = Vector3.zero - transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += velocidad * direccion;

        Vector2 positionP = Camera.main.WorldToScreenPoint(transform.position); 

        if ( positionP.x <0 ||  positionP.x > Screen.width || positionP.y <0 || positionP.y > Screen.height) {
            Destroy(gameObject);
        }

    }
}
