using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    [Range(0, 1)]
    //[Serializefield] //sirve para ver un campo en unity
    public float velocidad;
    SpriteRenderer sr;
    // Start is called before the first frame update
    void Start()
    {
            Debug.Log($"Mi posición es: {transform.position}");
            sr = GetComponent<SpriteRenderer>();
           // sr.color = Color.green;

    }

    // Update is called once per frame
    void Update()
    {

       float horizontal = Input.GetAxis("Horizontal");
       float vertical = Input.GetAxis("Vertical");
       Vector3 direction = new Vector3(horizontal, vertical, 0); 
       transform.position += direction * velocidad;

    }
}
