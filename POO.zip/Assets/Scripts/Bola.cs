using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bola : MonoBehaviour
{
     Vector3 direction;
        float vel = 5;
        [SerializeField]
        GameObject pelota;

    // Start is called before the first frame update
    void Start()
    {


        int r = Random.Range(0, 4); // r es un numero del 0 al 3
        Vector3 direction;
        float vel = 5;


        if (r == 0) {
            Debug.Log("Derecha arriba");
            direction = new Vector3(1, 1, 0);
            


        } else if (r == 1) {
            Debug.Log("Izquierda arriba");
            direction = new Vector3(-1, 1, 0);
        } else if (r == 2) {
            Debug.Log("Izquierda debajo");
            direction = new Vector3(-1, -1, 0);
        } else {
            Debug.Log("derecha debajo");
            direction = new Vector3(1, -1, 0);
        }

        
        Vector3 force = direction * vel;
        GetComponent<Rigidbody2D>().AddForce(force, ForceMode2D.Impulse);


        
        
    }

    // Update is called once per frame
    void Update()
    {
       transform.position += vel * direction;

        Vector2 positionP = Camera.main.WorldToScreenPoint(transform.position); 

        if ( positionP.x <0 ||  positionP.x > Screen.width || positionP.y <0 || positionP.y > Screen.height) {
            SpawnObject();
            Destroy(gameObject);
        }

        if (gameObject == null){
            
            

            
        }
    }
   void SpawnObject(){
    Vector2 position = new Vector2(0, 0);
    
   
    Instantiate(pelota, (Vector2) position, Quaternion.identity);


   }
}

