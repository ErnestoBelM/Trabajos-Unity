using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnMeteoritos : MonoBehaviour
{
    [SerializeField]
    GameObject Meteo;
    public float TiempoSpawn;
    [SerializeField]
    Transform[] Puntos;
     public float tiempo;
     

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
         if (tiempo > TiempoSpawn){
            int random = Random.Range(0, Puntos.Length);
            GameObject cubos =  Instantiate(Meteo, Puntos[random].position, Quaternion.identity, transform);
            tiempo -= TiempoSpawn;

        }
        tiempo += Time.deltaTime;

        
    }
}
