using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnPlayer : MonoBehaviour

{
    [SerializeField]
        GameObject Player;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
         if  (Player == null) {
            SpawnObject();
           
        }
    }
     void SpawnObject(){
    Vector2 position = new Vector2(0, 0);
    
   
    Instantiate(Player, (Vector2) position, Quaternion.identity);


   }
}
