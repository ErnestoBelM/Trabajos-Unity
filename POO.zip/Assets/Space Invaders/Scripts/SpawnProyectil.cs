using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpawnProyectil : MonoBehaviour
{
     public GameObject proyectil;
     public int ammo;
     private int _ammo;

    GameObject municionObject;

    // Start is called before the first frame update
    void Start()
    {
        municionObject = GameObject.Find("municion");
        GameObject.FindWithTag("GameController");
        _ammo = ammo;

    }

    // Update is called once per frame
    void Update()
    {
       
      

        bool spacePressed = Input.GetKeyDown("space");
        bool Reload = Input.GetKeyDown("up");

         if (Reload && _ammo < ammo){


            int falta = ammo - _ammo;

            //_ammo += Mathf.Min(2, falta);

            
             _ammo++;

            if (_ammo < ammo) {
                _ammo++;
            }

             UpdateUI();
         } 

        
        
       if (spacePressed && _ammo > 0){
             SpawnObject();
             _ammo--;
             UpdateUI();
         } 
    }
     void SpawnObject()
    {
        Instantiate(proyectil, (Vector2)  transform.position, Quaternion.identity);

    }

    void UpdateUI() 
    {
        
        Text componenteText = municionObject.GetComponent<Text>();
        componenteText.text = "MUNICIÓN: " + _ammo;
    }

    
}
