using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimientoNave : MonoBehaviour
{
      public float velocidad = 0.01f;
      public GameObject proyectil;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update() 
    {
        bool spacePressed = Input.GetKeyDown("space");
        float Horizontal = Input.GetAxis("Horizontal");
        Vector3 direction = new Vector3(Horizontal, 0, 0);

        transform.position += direction * velocidad * Time.deltaTime;

        //  if (spacePressed){
        //      SpawnObject();
        //  }
         
          Vector2 positionP = Camera.main.WorldToScreenPoint(transform.position); 
        if (positionP.y <0 || positionP.y > Screen.height) {
        
            Destroy(proyectil);
            
            }

       
        Animator componenteAnim = gameObject.GetComponent<Animator>();
        componenteAnim.SetFloat("direccion", Horizontal);
        
   


        // if (transform.position.x > 10.6)
        // {
        //     transform.position = new Vector3(10.599f, transform.position.y, transform.position.z);
            
        // } else if (transform.position.x < -10.6)
        // {
        //     transform.position = new Vector3(-10.599f, transform.position.y, transform.position.z);
        // } 
        // else
        // {
        //     transform.position += direction * velocidad;
        // }
        
        

    }
   
    

    // void SpawnObject()
    // {
    //     Instantiate(proyectil, (Vector2)  transform.position, Quaternion.identity);

       
    // }
   

}
