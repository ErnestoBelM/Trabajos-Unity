using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Meteo : MonoBehaviour
{
      public float vel = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
         transform.position += vel * Vector3.down * Time.deltaTime;
    }

      void OnTriggerEnter2D(Collider2D collision)
    {
      
        if (collision.gameObject.tag == "Player")
        {
            print(collision.gameObject.name);

            Destroy(collision.gameObject);
            Destroy(gameObject);
            var objeto = GameObject.FindWithTag("GameController");
            var objeto2 = GameObject.FindWithTag("Canvas2");            
            GameManager componenteGM = objeto.GetComponent<GameManager>();
            Text componenteText = objeto2.GetComponent<Text>();
            componenteGM.puntuacion++ ;           
            //print(componenteGM.puntuacion);
            componenteText.text = "PUNTUACIÓN: " + componenteGM.puntuacion.ToString();
        }

    
        
    }

}
