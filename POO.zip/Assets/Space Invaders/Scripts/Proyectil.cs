using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Proyectil : MonoBehaviour
{
    [SerializeField]
    public float vel = 1;
   // Vector3 direction;
    // Start is called before the first frame update

    void Start()
    {
        //  Vector3 direction;
        //  direction = new Vector3(1, 1, 0);
        
        
    }

    // Update is called once per frame
    void Update()
    {
      
        //Vector2 posicion = new Vector2( Random.Range(0, Screen.width), Random.Range(0, Screen.height));
        transform.position += vel * Vector3.up * Time.deltaTime;

        




    }
     void OnTriggerEnter2D(Collider2D collision)
    {
        // 
        
       

        if (collision.gameObject.tag == "Meteo")
        {
            Destroy(gameObject);
            print(collision.gameObject.name);
            Destroy(collision.gameObject);
            
            var objeto = GameObject.FindWithTag("GameController");
            var objeto2 = GameObject.FindWithTag("Canvas");            
            GameManager componenteGM = objeto.GetComponent<GameManager>();
            Text componenteText = objeto2.GetComponent<Text>();
            componenteGM.puntuacion++ ;           
            //print(componenteGM.puntuacion);
            componenteText.text = "PUNTUACIÓN: " + componenteGM.puntuacion.ToString();
        }
    }

}
