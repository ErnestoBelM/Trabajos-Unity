using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;





public class Enemy : MonoBehaviour
{

    public enum State {Chase,Patrol};
    public GameObject player;
    public GameObject[] patrolPoints;
    NavMeshAgent agent;

    public State currentState = State.Patrol;

    public int currentPointIndex = 0;


    // Start is called before the first frame update
    void Start()
    {
        agent = this.GetComponent<NavMeshAgent>();
    }


    // Update is called once per frame

    

    

    void Update(){


        if (currentState == State.Chase) {
            Chase();
        } else if (currentState == State.Patrol) {
            Patrol();
        }


        // switch(currentState){
        //     case State.Patrol:
        //         Patrol();
        //         break;
        //     case State.Chase:
        //         Chase();
        //         break;
        // }


    }
    void Chase(){
        Vector3 targetPoint = player.transform.position;
        agent.SetDestination(targetPoint);
        if (Input.GetKeyDown(KeyCode.Space));
    
    }


    
    void Patrol()    
    {
        Vector3 targetPoint = patrolPoints[currentPointIndex].transform.position;

        agent.SetDestination(targetPoint);

        Vector3 direction = targetPoint - this.transform.position;
        //direction.magnitude

        //float cercania = Vector3.Distance(this.transform.position,targetPoint);
        //print(cercania);
        if(direction.magnitude<2f){
            currentPointIndex = currentPointIndex +1;
            if(currentPointIndex == patrolPoints.Length) {
                currentPointIndex=0;
            }
        }
        
    }
}
