using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FSM3 : MonoBehaviour
{


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void PatrolUpdate(){
        //int r = Random.Range(0, patrolPoints.Length);
        //Transform nextpoint = patrolPoints[r];
        //agent.SetDestination(patrolPoints[0].position);
        //if (Input.GetKeyDown(KeyCode.Space)){
       //     currentState = State3.Chase;
       // }
        bool hasNextPoint != null;
        if (hasNextPoint) {

            Vector2 0m = new Vector2(1,0,1);
            bool arrived = Vector3.Distance(transform.position.x, transform.position.y);
            Vector2 pointPosition = new Vector2(nextPoint)
        }



    }
    void ChaseUpdate(){



    }






}
