using System.Collections;
using System.Collections.Generic;
using UnityEngine;
enum State {

    Patrol,
    Chase,
    Idle
}

public class FSM : MonoBehaviour
{
    State currentState;
  //  [SerializeField]
 //   State state;
   // [SerializeField]
  //  Phase phase;
    

    // Start is called before the first frame update
    void Start()
    {
        currentState = State.Patrol;
        
    }

    // Update is called once per frame
    void Update()
    {
        // switch (currentState) {
        //     case State.Patrol:
        //     PatrolUpdate();
        //     break;
        //     case State.Chase:
        //     ChaseUpdate();
        //     break;
        //     case State.Idle:
        //     IdleUpdate();
        //     break;
        // }
    }
}


// void PatrolUpdate() {
//     Debug.Log("Patrol Update");
//     if (Input.GetKeyDown(get))async 
// void ChaseUpdate() {
// }
// void PatrolUpdate() {
// }
// void IdleUpdate() {

// }
// }
